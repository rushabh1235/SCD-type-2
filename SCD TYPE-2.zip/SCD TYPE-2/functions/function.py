# Databricks notebook source
# get current admin name
def get_databricks_admin_name():

    # Get the username from the entry point
    return dbutils.notebook.entry_point.getDbutils().notebook().getContext().tags().get("user").getOrElse(None)

# COMMAND ----------

# Get the current notebook path
def get_program_path():

    # Get the notebookpath from the entry point
    return dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().getOrElse(None)

# COMMAND ----------

#get source file or table location
def get_source_name(database_name, table_name):
    full_table_name = f"{database_name}.{table_name}"
    return full_table_name