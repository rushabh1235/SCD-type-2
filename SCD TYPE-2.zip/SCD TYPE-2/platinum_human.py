# Databricks notebook source
# MAGIC %run ./functions/function

# COMMAND ----------

# DBTITLE 1,PLATINUM TABLE OPERATIONS
from delta.tables import *
from pyspark.sql.functions import *

source_path = get_source_name('default','goldhumans')

goldTable = DeltaTable.forPath(spark, "dbfs:/user/hive/warehouse/goldhumans")
goldDF = goldTable.toDF()

#filter invalid record from gold_table
gold_table = goldDF.withColumn("fromdatekey", expr("date_format(from_date, 'yyyyMMdd')").cast("int")) \
                   .withColumn("todatekey",expr("date_format(coalesce(to_date, '9999-12-31'), 'yyyyMMdd')").cast("int")) \
                   .withColumn("audit_source_path",lit(source_path)) \
                   .filter((col("todatekey") >= col("fromdatekey")))
gold_table = gold_table.filter(col("is_delete") != lit(True))

#load only valid record in platinum table
gold_table.write.format('delta').option("mergeSchema", "true").mode('overwrite').save('dbfs:/user/hive/warehouse/platinumhumans')