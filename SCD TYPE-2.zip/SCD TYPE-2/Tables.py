# Databricks notebook source
# %sql
# CREATE OR REPLACE TABLE silver_human (
  # sr int,
  # name string,
  # gender string,
  # age int,
  # country string,
  # audit_opr string,
  # audit_created_date TIMESTAMP,
  # audit_updated_date TIMESTAMP,
  # hashkey string
# )
# USING DELTA 
# LOCATION '/FileStore/tables/SILVER_human'
from pyspark.sql.types import *
schema = StructType([
    StructField("sr", IntegerType()),
    StructField("name", StringType()),
    StructField("gender", StringType()),
    StructField("age", IntegerType()),
    StructField("country", StringType()),
    StructField("audit_operation", StringType()),
    StructField("audit_created_date", TimestampType()),
    StructField("audit_updated_date", TimestampType()),
    StructField("audit_created_by", StringType()),
    StructField("audit_updated_by", StringType()),
    StructField("audit_source_path", StringType()),
    StructField("audit_program_path", StringType()),
    StructField("hashkey", StringType())
])
silverhumans = spark.createDataFrame([], schema=schema)
silverhumans.write.format("delta").mode("overwrite").saveAsTable('default.silverhumans')

# COMMAND ----------

# %sql
# CREATE OR REPLACE TABLE gold_humans (
#   surrogate_key int,
#   from_date date,
#   to_date date,
#   sr int,
#   name string,
#   gender string,
#   age int,
#   country string,
#   audit_opr string,
#   audit_created_date TIMESTAMP,
#   audit_updated_date TIMESTAMP,
#   is_latest boolean,
#   is_delete boolean,
#   hashkey string
# )
# USING DELTA 
# LOCATION '/FileStore/tables/GOLD_humans'

from pyspark.sql.types import *
schema = StructType([
    StructField("human_key", IntegerType()),
    StructField("from_date", DateType()),
    StructField("to_date", DateType()),
    StructField("sr", IntegerType()),
    StructField("name", StringType()),
    StructField("gender", StringType()),
    StructField("age", IntegerType()),
    StructField("country", StringType()),
    StructField("audit_operation", StringType()),
    StructField("audit_created_date", TimestampType()),
    StructField("audit_updated_date", TimestampType()),
    StructField("audit_created_by", StringType()),
    StructField("audit_updated_by", StringType()),
    StructField("audit_source_path", StringType()),
    StructField("audit_program_path", StringType()),
    StructField("is_latest", BooleanType()),
    StructField("is_delete", BooleanType()),
    StructField("hashkey", StringType())
])
goldhumans = spark.createDataFrame([], schema=schema)
goldhumans.write.format("delta").mode("overwrite").saveAsTable('default.goldhumans')

# COMMAND ----------

# %sql
# CREATE OR REPLACE TABLE platinum_humans (
#   surrogate_key int,
#   from_date date,
#   to_date date,
#   fromdatekey int,
#   todatekey int,
#   sr int,
#   name string,
#   gender string,
#   age int,
#   country string,
#   audit_opr string,
#   audit_created_date TIMESTAMP,
#   audit_updated_date TIMESTAMP,
#   is_latest boolean,
#   is_delete boolean
# )
# USING DELTA 
# LOCATION '/FileStore/tables/PLATINUM_HUMANS'

from pyspark.sql.types import *
schema = StructType([
    StructField("human_key", IntegerType()),
    StructField("from_date", DateType()),
    StructField("to_date", DateType()),
    StructField("fromdatekey", IntegerType()),
    StructField("todatekey", IntegerType()),
    StructField("sr", IntegerType()),
    StructField("name", StringType()),
    StructField("gender", StringType()),
    StructField("age", IntegerType()),
    StructField("country", StringType()),
    StructField("audit_operation", StringType()),
    StructField("audit_created_date", TimestampType()),
    StructField("audit_updated_date", TimestampType()),
    StructField("audit_created_by", StringType()),
    StructField("audit_updated_by", StringType()),
    StructField("audit_source_path", StringType()),
    StructField("audit_program_path", StringType()),
    StructField("is_latest", BooleanType()),
    StructField("is_delete", BooleanType()),
    StructField("hashkey", StringType())
])
platinumhumans = spark.createDataFrame([], schema=schema)
platinumhumans.write.format("delta").mode("overwrite").saveAsTable('default.platinumhumans')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from platinumhumans

# COMMAND ----------

# %sql
# ALTER TABLE platinum_humans ADD COLUMN audit_program_path string AFTER audit_source_path;

# COMMAND ----------

# %sql
# truncate table silver_human;
# truncate table gold_humans;
# truncate table platinum_humans

# COMMAND ----------

# dbutils.fs.rm("dbfs:/FileStore/tables/silverhuman", True)
# dbutils.fs.rm("dbfs:/FileStore/tables/goldhuman", True)
# dbutils.fs.rm("dbfs:/FileStore/tables/platinumhuman", True)