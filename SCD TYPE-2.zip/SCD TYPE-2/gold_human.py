# Databricks notebook source
# MAGIC %run ./functions/function

# COMMAND ----------

# DBTITLE 1,GOLD TABLE OPERATIONS
# gold table operation
 
from pyspark.sql.functions import current_timestamp, row_number, lit
from pyspark.sql.functions import *
from delta.tables import *
from pyspark.sql.window import Window
from pyspark.sql.functions import current_timestamp
from pyspark.sql.functions import monotonically_increasing_id

#audit fields
created_by = get_databricks_admin_name()
updated_by = get_databricks_admin_name()
notebook_path = get_program_path()
source_path = get_source_name('default','silverhumans')

#silver delta table instance to dataframe
silverTable = DeltaTable.forPath(spark, "dbfs:/user/hive/warehouse/silverhumans")
silverDF = silverTable.toDF()
 
#gold delta table instance to dataframe
goldTable = DeltaTable.forPath(spark, "dbfs:/user/hive/warehouse/goldhumans")
goldDF = goldTable.toDF()

#filter only latest records
goldDF = goldDF.filter(col('is_latest') == 'true')
 
#join silver and gold table
joinDF = silverDF.alias('silverDF')\
                  .join(goldDF.alias('goldDF'),\
                        (silverDF.sr == goldDF.sr),"leftouter")\
                        .select(silverDF["*"],goldDF.sr.alias("gold_sr"),goldDF.hashkey.alias("gold_hashkey"),\
                          goldDF.audit_operation.alias("gold_audit_operation"),goldDF.is_latest.alias("gold_is_latest"))
 
#filter deleted record
delDF = joinDF.filter((col("gold_sr").isNotNull()) & (col("audit_operation") == "deleted")).withColumn("mergekey", joinDF.sr)
recreat_delDF = joinDF.filter((col("gold_sr").isNotNull()) & (col("audit_operation") == "deleted")).withColumn("mergekey", lit(None))
 
xyz = joinDF.filter("sr == gold_sr and (audit_operation=='updated' and gold_audit_operation == 'deleted' and gold_is_latest == 'true')").withColumn("mergekey", joinDF.sr)
 
#filter only updated and new record
filterDF = joinDF.filter(xxhash64(joinDF.hashkey) != xxhash64(joinDF.gold_hashkey))
 
#add merger key for updated record
updatedDF = filterDF.filter("gold_sr is not null and gold_audit_operation != 'deleted'").withColumn("mergekey", filterDF.sr)
 
# perform union operation between deleteddata and updateddata
scdDF = updatedDF.unionAll(delDF).unionAll(xyz)
 
#add merger key for new record
newdataDF = filterDF.filter("gold_sr is null").withColumn("mergekey", filterDF.sr)
 
#add merger key as ""null"" for updated record
recreat_updatedDF = filterDF.filter("gold_sr is not null and gold_audit_operation != 'deleted'").withColumn("mergekey", lit(None))
 
#add merge key as ""null"" for past deleted record
samedataDF = joinDF.filter("sr == gold_sr and (audit_operation=='updated' and (gold_audit_operation == 'deleted' or gold_audit_operation == 'updated'))").withColumn("mergekey", lit(None))
 
# perform union operation between newdata and updateddata
scd = newdataDF.unionAll(recreat_updatedDF).unionAll(samedataDF).unionAll(recreat_delDF)
 
#Find the maximum human_key from the goldDF DataFrame
max_key = goldDF.agg({"human_key" : "max"}).collect()[0][0]
 
#add human_key
if max_key is not None:
    new_data = scd.withColumn("human_key",row_number().over(Window.orderBy('sr')) + max_key)
else:
    new_data = scd.withColumn("human_key",row_number().over(Window.orderBy('sr')))
 
#final_data
final_data = new_data.unionByName(scdDF, allowMissingColumns=True)
 
#filter only target table data
updated_or_new_date = {col: expr(f"source.{col}") for col in final_data.drop("gold_sr","gold_hashkey","gold_audit_operation","gold_is_latest", "mergekey","audit_operation").columns}
 
# # apply merge operation on scdDF and gold table
goldTable.alias("target").merge(final_data.alias("source"),"target.sr = source.mergekey") \
.whenMatchedUpdate(
  condition = "target.is_latest = true AND ((target.hashkey <> source.hashkey OR target.hashkey == source.hashkey) AND target.audit_operation == 'deleted')",
  set = {                                      
    "is_latest": "false",
    "audit_updated_by":lit(updated_by)
  }
).whenMatchedUpdate(
  condition = "target.is_latest = true AND (target.hashkey <> source.hashkey)",
  set = {                                      
    "is_latest": "false",
    "to_date": "current_date()-1",
    "audit_operation": "source.audit_operation",
    "audit_updated_date": "source.audit_updated_date",
    "audit_updated_by":lit(updated_by)
  }
).whenMatchedUpdate(
  condition="target.is_latest = true AND source.audit_operation = 'deleted' AND target.is_delete = false",
  set = {"audit_operation":lit("updated"),"to_date": "current_date()-1","is_latest":"false",
         "audit_updated_date": "source.audit_updated_date","audit_updated_by":lit(updated_by)}
).whenNotMatchedInsert(
  values={
        **updated_or_new_date,
        "audit_source_path":lit(source_path),  
        "from_date": "current_date()",
        "to_date":"CASE WHEN source.audit_operation != 'deleted' THEN NULL ELSE current_date() END",
        "audit_operation":"CASE WHEN source.audit_operation != 'deleted' THEN 'insert' else 'deleted' END",
        "is_latest": "true",
        "is_delete": "CASE WHEN source.audit_operation != 'deleted' THEN false else true END"
    }
).execute()