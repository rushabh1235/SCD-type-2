# Databricks notebook source
# DBTITLE 1,BRONZE TABLE OPERATIONS
# Bronze
from pyspark.sql.types import *
from pyspark.sql.functions import *
custom_schema = StructType([
    StructField("sr", IntegerType(), True),
    StructField("name", StringType(), True),
    StructField("gender", StringType(), True),
    StructField("age", IntegerType(), True),
    StructField("country", StringType(), True)
])
sourcedata = spark.read.csv("dbfs:/FileStore/tables/human.csv",header=True,schema=custom_schema)

#genrate hashkey
hash_col = ['name','gender','age','country']
# sourcedata = sourcedata.withColumn("country",when(col("sr")==3,lit("USA")).otherwise(col("country")))
# sourcedata = sourcedata.filter(col("sr")!=3)
sourcedata = sourcedata.withColumn("hashkey", lit(sha2(concat_ws("~", *hash_col),256)))

display(sourcedata)

# COMMAND ----------

# audit_created_by
# audit_updated_by

def get_databricks_admin_name():

    # Get the username 
    username = dbutils.notebook.entry_point.getDbutils().notebook().getContext().tags().get("user").getOrElse(None)

    return username

# get_databricks_admin_name()

# # audit_program_path
# Get the current notebook path
# def get_program_path():
#     notebook_path = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().getOrElse(None)
#     return notebook_path
# Print the notebook path
# get_program_path()

# COMMAND ----------

# DBTITLE 1,SILVER TABLE OPERATIONS
# silver table operations

from pyspark.sql.functions import current_timestamp, row_number, lit
from pyspark.sql.window import Window
from delta.tables import *

created_by = get_databricks_admin_name()
display(created_by)
# updated_by = get_databricks_admin_name()
# notebook_path = get_program_path()

# delta table isinstance
targetTable = DeltaTable.forPath(spark, "/FileStore/tables/SILVER_human")

# merge and update condition
mergecondition = "target.sr = source.sr"
updatecondition = "target.hashkey != source.hashkey"

# Generate update expressions dynamically
updated_or_new_date = {col: expr(f"source.{col}") for col in sourcedata.columns}

targetTable.alias("target")\
.merge(sourcedata.alias("source"), mergecondition)\
    .whenMatchedUpdate(
        condition = updatecondition,
        set=
        {**updated_or_new_date, "audit_opr": lit("updated"), "audit_updated_date": current_timestamp()}) \
    .whenMatchedUpdate(
        condition = "target.audit_opr = 'deleted'",
        set=
        {**updated_or_new_date, "audit_opr": lit("updated"), "audit_updated_date": current_timestamp()}) \
    .whenNotMatchedInsert(
        values ={**updated_or_new_date, "audit_opr": lit("insert"),"audit_created_date": current_timestamp(), "audit_updated_date": current_timestamp(),"audit_created_by":lit(created_by)}) \
    .whenNotMatchedBySourceUpdate(
        condition="target.audit_opr!='deleted'",
        set = 
        {"audit_opr":lit("deleted"),"audit_updated_date":current_timestamp()}) \
.execute()

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from silver_human

# COMMAND ----------

# DBTITLE 1,GOLDEN TABLE OPERATIONS
# gold table operation
 
from pyspark.sql.functions import current_timestamp, row_number, lit
from pyspark.sql.functions import *
from delta.tables import *
from pyspark.sql.window import Window
from pyspark.sql.functions import current_timestamp
from pyspark.sql.functions import monotonically_increasing_id
 
#silver delta table instance to dataframe
silverTable = DeltaTable.forPath(spark, "/FileStore/tables/SILVER_human")
silverDF = silverTable.toDF()
 
#gold delta table instance to dataframe
goldTable = DeltaTable.forPath(spark, "/FileStore/tables/GOLD_humans")
goldDF = goldTable.toDF()
 
#filter only latest records
goldDF = goldDF.filter(col('is_latest') == 'true')
 
#join silver and gold table
joinDF = silverDF.alias('silverDF')\
                  .join(goldDF.alias('goldDF'),\
                        (silverDF.sr == goldDF.sr),"leftouter")\
                        .select(silverDF["*"],goldDF.sr.alias("gold_sr"),goldDF.hashkey.alias("gold_hashkey"),\
                          goldDF.audit_opr.alias("gold_audit_opr"),goldDF.is_latest.alias("gold_is_latest"))
 
#filter deleted record
delDF = joinDF.filter((col("gold_sr").isNotNull()) & (col("audit_opr") == "deleted")).withColumn("mergekey", joinDF.sr)
recreat_delDF = joinDF.filter((col("gold_sr").isNotNull()) & (col("audit_opr") == "deleted")).withColumn("mergekey", lit(None))
 
xyz = joinDF.filter("sr == gold_sr and (audit_opr=='updated' and gold_audit_opr == 'deleted' and gold_is_latest == 'true')").withColumn("mergekey", joinDF.sr)
 
#filter only updated and new record
filterDF = joinDF.filter(xxhash64(joinDF.hashkey) != xxhash64(joinDF.gold_hashkey))
 
#add merger key for updated record
updatedDF = filterDF.filter("gold_sr is not null and gold_audit_opr != 'deleted'").withColumn("mergekey", filterDF.sr)
display(updatedDF)
 
# perform union operation between deleteddata and updateddata
scdDF = updatedDF.unionAll(delDF).unionAll(xyz)
 
#add merger key for new record
newdataDF = filterDF.filter("gold_sr is null").withColumn("mergekey", filterDF.sr)
 
#add merger key as ""null"" for updated record
recreat_updatedDF = filterDF.filter("gold_sr is not null and gold_audit_opr != 'deleted'").withColumn("mergekey", lit(None))
 
#add merge key as ""null"" for past deleted record
samedataDF = joinDF.filter("sr == gold_sr and (audit_opr=='updated' and (gold_audit_opr == 'deleted' or gold_audit_opr == 'updated'))").withColumn("mergekey", lit(None))
 
# perform union operation between newdata and updateddata
scd = newdataDF.unionAll(recreat_updatedDF).unionAll(samedataDF).unionAll(recreat_delDF)
 
#Find the maximum surrogate_key from the goldDF DataFrame
max_key = goldDF.agg({"surrogate_key" : "max"}).collect()[0][0]
 
#add surrogate_key
if max_key is not None:
    new_data = scd.withColumn("surrogate_key",row_number().over(Window.orderBy('sr')) + max_key)
else:
    new_data = scd.withColumn("surrogate_key",row_number().over(Window.orderBy('sr')))
 
#final_data
final_data = new_data.unionByName(scdDF, allowMissingColumns=True)
 
#filter only target table data
updated_or_new_date = {col: expr(f"source.{col}") for col in final_data.drop("gold_sr","gold_hashkey","gold_audit_opr","gold_is_latest", "mergekey","audit_opr").columns}
 
# # apply merge operation on scdDF and gold table
goldTable.alias("target").merge(final_data.alias("source"),"target.sr = source.mergekey") \
.whenMatchedUpdate(
  condition = "target.is_latest = true AND ((target.hashkey <> source.hashkey OR target.hashkey == source.hashkey) AND target.audit_opr == 'deleted')",
  set = {                                      
    "is_latest": "false"
  }
).whenMatchedUpdate(
  condition = "target.is_latest = true AND (target.hashkey <> source.hashkey)",
  set = {                                      
    "is_latest": "false",
    "to_date": "current_date()-1",
    "audit_opr": "source.audit_opr",
    "audit_updated_date": "source.audit_updated_date"
  }
).whenMatchedUpdate(
  condition="target.is_latest = true AND source.audit_opr = 'deleted' AND target.is_delete = false",
  set = {"audit_opr":lit("updated"),"to_date": "current_date()-1","is_latest":"false",
         "audit_updated_date": "source.audit_updated_date"}
).whenNotMatchedInsert(
  values={
        **updated_or_new_date,  
        "from_date": "current_date()",
        "to_date":"CASE WHEN source.audit_opr != 'deleted' THEN NULL ELSE current_date() END",
        "audit_opr":"CASE WHEN source.audit_opr != 'deleted' THEN 'insert' else 'deleted' END",
        "is_latest": "true",
        "is_delete": "CASE WHEN source.audit_opr != 'deleted' THEN false else true END"
    }
).execute()

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from gold_humans order by sr,surrogate_key

# COMMAND ----------

# DBTITLE 1,PLATINUM TABLE OPERATIONS
goldTable = DeltaTable.forPath(spark, "/FileStore/tables/GOLD_humans")
goldDF = goldTable.toDF()

#filter invalid record from gold_table
gold_table = goldDF.withColumn("fromdatekey", expr("date_format(from_date, 'yyyyMMdd')").cast("int")) \
                   .withColumn("todatekey",expr("date_format(coalesce(to_date, '9999-12-31'), 'yyyyMMdd')").cast("int")) \
                   .filter((col("todatekey") >= col("fromdatekey")))
gold_table = gold_table.filter(col("is_delete") != lit(True))
#load only valid record in platinum table
gold_table.write.format('delta').option("mergeSchema", "true").mode('overwrite').save('dbfs:/FileStore/tables/PLATINUM_HUMANS')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from platinum_humans

# COMMAND ----------

# %sql
# truncate table silver_human;
# truncate table gold_humans;
# truncate table platinum_humans

# COMMAND ----------

