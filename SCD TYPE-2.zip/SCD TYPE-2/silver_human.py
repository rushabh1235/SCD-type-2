# Databricks notebook source
# DBTITLE 1,BROZE TABLE OPERATIONS
# Bronze
from pyspark.sql.types import *
from pyspark.sql.functions import *
custom_schema = StructType([
    StructField("sr", IntegerType(), True),
    StructField("name", StringType(), True),
    StructField("gender", StringType(), True),
    StructField("age", IntegerType(), True),
    StructField("country", StringType(), True)
])
sourcedata = spark.read.csv("dbfs:/FileStore/tables/human.csv",header=True,schema=custom_schema)

#genrate hashkey
hash_col = ['name','gender','age','country']
# sourcedata = sourcedata.withColumn("country",when(col("sr")==3,lit("CHINA")).otherwise(col("country")))
# sourcedata = sourcedata.filter(col("sr")!=3)
sourcedata = sourcedata.withColumn("hashkey", lit(sha2(concat_ws("~", *hash_col),256)))

# COMMAND ----------

# MAGIC %run ./functions/function

# COMMAND ----------

# DBTITLE 1,SILVER TABLE OPERATIONS
# silver table operations
from pyspark.sql.functions import current_timestamp, row_number, lit
from pyspark.sql.window import Window
from delta.tables import *

#audit fields
created_by = get_databricks_admin_name()
updated_by = get_databricks_admin_name()
notebook_path = get_program_path()
source_path = get_source_name('tables','human.csv')

# delta table isinstance
targetTable = DeltaTable.forPath(spark, "dbfs:/user/hive/warehouse/silverhumans")

# merge and update condition
mergecondition = "target.sr = source.sr"
updatecondition = "target.hashkey != source.hashkey"

# Generate update expressions dynamically
updated_or_new_date = {col: expr(f"source.{col}") for col in sourcedata.columns}

targetTable.alias("target")\
.merge(sourcedata.alias("source"), mergecondition)\
    .whenMatchedUpdate(
        condition = updatecondition,
        set=
        {**updated_or_new_date, "audit_operation": lit("updated"), "audit_updated_date": current_timestamp(),"audit_updated_by":lit(updated_by)}) \
    .whenMatchedUpdate(
        condition = "target.audit_operation = 'deleted'",
        set=
        {**updated_or_new_date, "audit_operation": lit("updated"), "audit_updated_date": current_timestamp(),"audit_updated_by":lit(updated_by)}) \
    .whenNotMatchedInsert(
        values ={**updated_or_new_date,
                  "audit_operation": lit("insert"),"audit_created_date": current_timestamp(), "audit_updated_date": current_timestamp(), "audit_created_by":lit(created_by),"audit_updated_by":lit(updated_by), "audit_source_path":lit(source_path),
                  "audit_program_path":lit(notebook_path)}) \
    .whenNotMatchedBySourceUpdate(
        condition="target.audit_operation!='deleted'",
        set = 
        {"audit_operation":lit("deleted"),"audit_updated_date":current_timestamp(),"audit_updated_by":lit(updated_by)}) \
.execute()